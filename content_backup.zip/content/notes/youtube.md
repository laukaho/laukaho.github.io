---
date: 2018-10-26
tags: ['video', 'note']
---

<Embed
  src="https://www.youtube.com/embed/dpw9EHDh2bM"
/>

An example of how you can embed YouTube videos in a note.
