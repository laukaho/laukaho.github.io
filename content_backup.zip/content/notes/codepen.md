---
date: 2018-10-02
tags: ['note', 'code']
---

<iframe height="565" style="width: 100%;" scrolling="no" title="Liquid button" src="https://codepen.io/electerious/embed/gOOLgjd?height=265&theme-id=default&default-tab=js,result" frameborder="no" allowtransparency="true" allowfullscreen="true">
  See the Pen <a href='https://codepen.io/electerious/pen/gOOLgjd'>Liquid button</a> by Tobias Reich
  (<a href='https://codepen.io/electerious'>@electerious</a>) on <a href='https://codepen.io'>CodePen</a>.
</iframe>

Embed Codepen code in note.
