---
date: 2017-03-02
tags: ['note', 'presentation', 'project']
---

<iframe src="https://docs.google.com/presentation/d/e/2PACX-1vThGw6fVolF-XuCkf9zru7Jdc4XTiUvc89ovDY3luRrfD0OUw3VVkoBJxe-NiM6jJ5q4egcRRQYU6i0/embed?start=false&loop=false&delayms=5000" frameborder="0" width="960" height="569" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe>

Embed google presentation in a note.
