---
date: 2019-08-05
tags: ['note', 'podcast']
---

<iframe
  height="200px"
  width="100%"
  frameborder="no"
  scrolling="no"
  seamless
  src="https://player.simplecast.com/62a1da0d-f39d-4d65-97d7-8faa48ae046f?dark=false"
></iframe>

This podcast on:

<p>
<FontAwesomeIcon icon={['fab', 'google']} />&nbsp;<a href="https://podcasts.google.com/?feed=aHR0cHM6Ly9mZWVkcy5zaW1wbGVjYXN0LmNvbS9YX3dTX1dZaA">Google Podcasts</a><br/>
<FontAwesomeIcon icon={['fab', 'apple']} />&nbsp;<a href="https://podcasts.apple.com/us/podcast/chats-with-kent-c-dodds/id1475543959">Apple Podcasts</a><br/>
<FontAwesomeIcon icon={['fab', 'spotify']} />&nbsp;<a href="https://open.spotify.com/show/7GkO2poedjbltWT5lduL5w">Spotify</a>
</p>

An example of how to embed podcast (in this case from simplecast, but you can use any other sources) in a note.
