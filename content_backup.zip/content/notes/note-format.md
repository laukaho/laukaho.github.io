---
date: 2019-11-02
tags: ['note', 'project']
---

**Note card** - the type of content that is fully displayed in the feed of the site - it is suitable for short notes (like this one), videos, podcasts, slides, etc.

Since this is markdown - here you can do _everything_ that allows you to do this format.

See below for examples of how you can use notes.
