---
title: Note Chronoblog
date: 2016-01-01
tags: ['note', 'project']
---

If you have any problems with the Chronoblog, or you have interesting ideas, write to the github issue: <FontAwesomeIcon icon={['fab', 'github']} /> [github.com/Chronoblog/gatsby-theme-chronoblog/issues](https://github.com/Chronoblog/gatsby-theme-chronoblog/issues)

You can also contact me on Twitter: <FontAwesomeIcon icon={['fab', 'twitter']} /> [twitter.com/Ganevru](https://twitter.com/Ganevru)

![banner-small](banner-small.png)
