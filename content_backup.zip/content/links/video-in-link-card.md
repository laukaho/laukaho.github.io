---
title: Video in Link Card
date: 2019-11-11
link: https://www.youtube.com/watch?v=7V6FFeZdFz4
tags: ['video', 'link']
---

<Embed
  src="https://www.youtube.com/embed/7V6FFeZdFz4"
/>

An example of how you can embed YouTube videos in a **link card**. Link leads to this video on YouTube.
