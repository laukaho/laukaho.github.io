---
title: 'Ghost Post'
cover: ./image.png
date: 2010-01-01
link: http://example.com
slug: invisible-ghost-post
description: 'this post has all of the right fields'
tags: ['notags']
draft: true
hide: true
---

This exists to populate GraphQL fields and avoid null errors. It should contain all of the available frontmatter.
