---
title: 'Link to Chronoblog Theme repo'
cover: ./image.jpg
date: 2019-11-12
link: https://github.com/Ganevru/gatsby-theme-chronoblog
tags: ['link', 'project']
---

**Link card** is a card, when clicked, the user goes to the specified link.

Use it to refer to your articles on other resources, to your new works (wherever they are posted: Github, Dribbble or anything else), to the certificates you received, and in general, to whatever is more convenient give a link.
